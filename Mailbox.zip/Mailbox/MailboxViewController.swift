//
//  MailboxViewController.swift
//  Mailbox
//
//  Created by Lambdin, Daniel on 4/17/16.
//  Copyright © 2016 Daniel Lambdin. All rights reserved.
//

import UIKit

class MailboxViewController: UIViewController, UIGestureRecognizerDelegate {

    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var messageView: UIView!
    @IBOutlet weak var messageImage: UIImageView!
    @IBOutlet weak var laterImage: UIImageView!
    @IBOutlet weak var archiveImage: UIImageView!
    @IBOutlet weak var feedImage: UIImageView!
    @IBOutlet weak var rescheduleView: UIView!
    @IBOutlet weak var listView: UIView!
    @IBOutlet weak var menuView: UIView!

    var messageInitialCenter: CGPoint!
    var laterImageInitialCenter: CGPoint!
    var feedInitialCenter: CGPoint!
    var archiveInitialCenter: CGPoint!
    
    
    let grey = UIColor(red: 226/255, green: 226/255, blue: 226/255, alpha: 1.0)
    let yellow = UIColor(red: 250/255, green: 211/255, blue: 51/255, alpha: 1.0)
    let brown = UIColor(red: 216/255, green: 166/255, blue: 117/255, alpha: 1.0)
    let green = UIColor(red: 112/255, green: 217/255, blue: 98/255, alpha: 1.0)
    let red = UIColor(red: 235/255, green: 84/255, blue: 51/255, alpha: 1.0)


    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        scrollView.contentSize = CGSize(width: 320, height: 2068)
        
        laterImage.alpha = 0.2
        archiveImage.alpha = 0.2
        
        messageInitialCenter = messageImage.center
        laterImageInitialCenter = laterImage.center
        feedInitialCenter = feedImage.center
        archiveInitialCenter = archiveImage.center
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func didPanMessage(sender: UIPanGestureRecognizer) {
        
        let translation = sender.translationInView(view)
        
        
        if sender.state == UIGestureRecognizerState.Began {

        
        } else if sender.state == UIGestureRecognizerState.Changed {
            
            messageImage.center.x = messageInitialCenter.x + translation.x
            
            if translation.x <= -40 && translation.x >= -60  {
                
                self.laterImage.alpha = 1.0
            
            } else if translation.x <= -60 && translation.x >= -240 {
                
                self.laterImage.center.x = self.laterImageInitialCenter.x + translation.x + 60
                self.laterImage.image = UIImage(named: "later_icon")
                
                self.messageView.backgroundColor = yellow
                
                self.archiveImage.alpha = 0
                
            } else if translation.x < -240 {
                
                self.laterImage.alpha = 1.0
                self.laterImage.center.x = self.laterImageInitialCenter.x + translation.x + 60
                self.laterImage.image = UIImage(named: "list_icon")
                
                self.messageView.backgroundColor = brown
                
            } else if translation.x >= 40 && translation.x <= 60 {
            
                self.archiveImage.alpha = 1.0
            
            } else if translation.x >= 60 && translation.x <= 240 {
            
                self.archiveImage.center.x = self.archiveInitialCenter.x + translation.x - 60
                self.archiveImage.image = UIImage(named: "archive_icon")
                
                self.messageView.backgroundColor = green
            
            } else if translation.x > 240 {
            
                self.archiveImage.center.x = self.archiveInitialCenter.x + translation.x - 60
                self.archiveImage.alpha = 1.0
                self.archiveImage.image = UIImage(named: "delete_icon")
                
                self.messageView.backgroundColor = red
            
            } else {
            
                self.laterImage.alpha = 0.2
                self.archiveImage.alpha = 0.2
                self.messageView.backgroundColor = grey
                
            }
        
        } else if sender.state == UIGestureRecognizerState.Ended {
            
            if translation.x <= -60 && translation.x >= -240 {
                
                self.laterImage.alpha = 0
                
                UIView.animateWithDuration(0.2, delay: 0, options: UIViewAnimationOptions.CurveEaseOut, animations: { () -> Void in
                    self.messageImage.center.x = self.messageInitialCenter.x - 320
                    }, completion: {
                        
                        (Bool) -> Void in
                        UIView.animateWithDuration(0.2, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                            
                            () -> Void in
                            self.rescheduleView.alpha = 1.0
                            
                            }, completion: {
                                
                                (Bool) -> Void in
                                
                        })
                })
            } else if translation.x < -240 {
            
                UIView.animateWithDuration(0.2, delay: 0, options: UIViewAnimationOptions.CurveEaseOut, animations: {
                    () -> Void in
                    self.messageImage.center.x = self.messageInitialCenter.x - 320
                    self.laterImage.alpha = 0
                    }, completion: { (Bool) -> Void in
                        UIView.animateWithDuration(0.2, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: { () -> Void in
                            self.listView.alpha = 1
                            }, completion: {
                                
                                (Bool) -> Void in
                                
                        })
                })
                
            } else if translation.x >= 60 && translation.x <= 240 {
                
                UIView.animateWithDuration(0.2, delay: 0, options: UIViewAnimationOptions.CurveEaseOut, animations: {
                    () -> Void in
                    self.messageView.center.x = self.messageInitialCenter.x + 320
                    self.archiveImage.alpha = 0
                    }, completion: {
                        
                        (Bool) -> Void in
                        
                        UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseInOut, animations: {
                            
                            () -> Void in
                            self.feedImage.center.y = self.feedInitialCenter.y - 84
                            }, completion: {
                                
                                (Bool) -> Void in
                        })
                        
                })
            } else if translation.x > 240 {
                UIView.animateWithDuration(0.15, delay: 0, options: UIViewAnimationOptions.CurveEaseOut, animations: {
                    
                    () -> Void in
                    
                    self.messageView.center.x = self.messageInitialCenter.x + 320
                    self.archiveImage.alpha = 0
                    }, completion: {
                        
                        (Bool) -> Void in
                    
                        UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseInOut, animations: {
                            
                            () -> Void in
                            self.feedImage.center.y = self.feedInitialCenter.y - 84
                            }, completion: {
                                
                                (Bool) -> Void in
                        })
                        
                })
            }
        
        }
    
    }
    
    @IBAction func didTapList(sender: AnyObject) {
        
        UIView.animateWithDuration(0.2, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: { () -> Void in
            self.listView.alpha = 0
        }) {
            
            (Bool) -> Void in
            
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseInOut, animations: {
                
                () -> Void in
                self.feedImage.center.y = self.feedInitialCenter.y - 84
                }, completion: {
                    
                    (Bool) -> Void in
                    
                    self.messageImage.center.x = self.messageInitialCenter.x
                    self.archiveImage.center.x = self.archiveInitialCenter.x
                    self.laterImage.center.x = self.laterImageInitialCenter.x
                    UIView.animateWithDuration(0.2, delay: 1.0, options: UIViewAnimationOptions.CurveEaseInOut, animations: {
                        
                        () -> Void in
                        self.feedImage.center.y = self.feedInitialCenter.y
                        
                        }, completion: {
                            
                            (Bool) -> Void in
                            
                    })
            })
            
        }
        
    }

    
    @IBAction func didTapReschedule(sender: AnyObject) {
        
        UIView.animateWithDuration(0.2, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: { () -> Void in
            self.rescheduleView.alpha = 0
        }) {
            
            (Bool) -> Void in
            
            UIView.animateWithDuration(0.3, delay: 0, options: UIViewAnimationOptions.CurveEaseInOut, animations: {
                
                () -> Void in
                self.feedImage.center.y = self.feedInitialCenter.y - 84
                }, completion: {
                    
                    (Bool) -> Void in
                    
                    self.messageImage.center.x = self.messageInitialCenter.x
                    self.archiveImage.center.x = self.archiveInitialCenter.x
                    self.laterImage.center.x = self.laterImageInitialCenter.x
                    UIView.animateWithDuration(0.2, delay: 1.0, options: UIViewAnimationOptions.CurveEaseInOut, animations: {
                        
                        () -> Void in
                        self.feedImage.center.y = self.feedInitialCenter.y
                        
                        }, completion: {
                            
                            (Bool) -> Void in
                            
                    })
            })
            
        }
        
    }
    
    
    
    
}
